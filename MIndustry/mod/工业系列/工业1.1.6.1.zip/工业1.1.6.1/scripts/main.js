
Vars.renderer.minZoom = 0.1;
Vars.renderer.maxZoom = 100;
// 读取蓝图时大小不能超过128
Vars.maxSchematicSize = 200;
var table = new Table();

var usedItems = new ObjectSet();

var scale = 0.85;

var player = null;

function setup(){
	table.background(Styles.black3);
	
	let iconSize = Vars.iconSmall * scale;
	
	table.table(null, itemsTable => {
	    var rebuild = () => {
    		itemsTable.clear();
    		
    		let i = 0;
    		Vars.content.items().each((item) => {
    		    if(!usedItems.contains(item)) return;
    		
    			itemsTable.image(item.uiIcon).size(iconSize);
    			
    			itemsTable.label(() => "" + UI.formatAmount(player.core() == null ? 0 : player.core().items.get(item))).padRight(5).minWidth(iconSize + 5).get().setFontScale(scale);
    			
    			if(++i % 4 == 0) itemsTable.row();
    		});
    	};
    	
    	itemsTable.update(t => {
    		Vars.content.items().each(item => {
    			if(player.core() != null && player.core().items.get(item) > 0 && usedItems.add(item)){
    			    rebuild();
    			}
    		});
    	});
	});
	
	table.row();
	
    table.table(null, info => {
        let addInfo = (icon, l) => {
    	    info.image(icon).size(iconSize).growX();
    	    info.label(l).padRight(5).get().setFontScale(scale);
    	}
    	
    	addInfo(Blocks.coreNucleus.uiIcon, () => player.team().cores().size + "");
        addInfo(UnitTypes.gamma.uiIcon, () => {
            let team = player.team();
            return"[#" + team.color + "]" + countPlayer(team) + "[]/[accent]" + Groups.player.size();
        });
    }).growX();
}

Events.on(ResetEvent, e => {
	usedItems.clear();
});

Events.on(EventType.ClientLoadEvent, cons(e => {
    player = Vars.player;
    
	setup();
	
	Vars.ui.hudGroup.fill(cons(t => {
		t.left().name = "coreItems/info";
		t.add(table);
		
		// 可拖动的ui
		t.addListener(extend(InputListener, {
			lastx: 0,
			lasty: 0,
	
			touchDown(event, x, y, pointer, button){
				var v = t.localToParentCoordinates(Tmp.v1.set(x, y));
				this.lastx = v.x;
				this.lasty = v.y;
				return true;
			},
	
			touchDragged(event, x, y, pointer){
				var v = t.localToParentCoordinates(Tmp.v1.set(x, y));
				t.translation.add(v.x - this.lastx, v.y - this.lasty);
				this.lastx = v.x;
				this.lasty = v.y;
			},
		}));
		
	}));
}
require('Planet');
require('VOG');
require('硅胶');
require('海绵钛');
require('钢筋');
require('混凝土瓶');
require('金');
require('锂');
require('铝');
require('石粉');
require('石灰');
require('石头');
require('石英');
require('石英砂');
require('水泥瓶');
require('碎石');
require('钛合金');
require('铁');
require('铁合金');
require('粗铁');