const lib = require("lib");
const 主岛 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(主岛, 6));
        this.super$load();
    }
}, "主岛", Planets.sun, 1);
const sS = require("sectorSize");
sS.planetGrid(主岛, 3.3);
//上面的是区块大小 ▲ 正常是3.3不建议乱改
主岛.generator = new ErekirPlanetGenerator();
//可以将[Erekir]改成任何游戏中有的星球
主岛.atmosphereColor = Color.valueOf("F75000");//大气颜色
主岛.atmosphereRadIn = 0.05;//大气层厚度起始值
主岛.atmosphereRadOut = 0.5;//大气层厚度结束值
主岛.localizedName = "主岛";//游戏内显示名称
主岛.visible = true;//是否可见
主岛.bloom = false;//开花渲染
主岛.accessible = true;//允许登陆
主岛.alwaysUnlocked = true;//始终未锁定
主岛.startSector = 15;//起始区块编号
主岛.orbitRadius = 40;//轨道环绕高度